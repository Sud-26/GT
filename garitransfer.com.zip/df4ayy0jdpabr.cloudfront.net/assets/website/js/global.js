$(document).ready(function() {
    $('#faq-show-more').on('click', function() {

        if ($('#faq').hasClass('hidden')) {
            $('#faq').removeClass('hidden');
        }
        $(this).remove();
    });

    $('.moreless-button').click(function() {
        $('.moretext').slideToggle();
        if ($(this).attr('data-text') == "showmore") {
            $(this).attr('data-text', 'showless');
            document.getElementById('arrowImage').src = "http://dev.reservation.garitransfer.com/img/showless.png";
        } else {
            $(this).attr('data-text', 'showmore');
            document.getElementById('arrowImage').src = "http://dev.reservation.garitransfer.com/img/showmore.png";
        }
    });
});